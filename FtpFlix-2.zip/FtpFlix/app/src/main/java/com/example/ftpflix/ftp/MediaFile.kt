package com.example.ftpflix.ftp

/**
 * A single playable video found on the FTP server.
 *
 * @param name      display name (filename without path)
 * @param fullPath  full remote path used to build the ftp:// stream URL
 * @param category  the parent folder name, used to group into Netflix-style rows
 * @param sizeBytes file size, for display
 */
data class MediaFile(
    val name: String,
    val fullPath: String,
    val category: String,
    val sizeBytes: Long
)

/** A row of media, grouped by folder — mirrors Netflix's "genre row" concept. */
data class MediaRow(
    val title: String,
    val items: List<MediaFile>
)
