package com.example.ftpflix.ftp

import com.example.ftpflix.FtpConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPFile
import org.apache.commons.net.ftp.FTPReply

/**
 * Talks to the FTP server running on your other phone, walks its directory
 * tree, and returns playable video files grouped by folder (for the
 * Netflix-style rows on the home screen).
 */
class FtpRepository {

    sealed class Result {
        data class Success(val rows: List<MediaRow>) : Result()
        data class Failure(val message: String) : Result()
    }

    suspend fun fetchLibrary(): Result = withContext(Dispatchers.IO) {
        val client = FTPClient()
        try {
            client.connectTimeout = 8000
            client.connect(FtpConfig.HOST, FtpConfig.PORT)

            if (!FTPReply.isPositiveCompletion(client.replyCode)) {
                return@withContext Result.Failure("Server refused connection (code ${client.replyCode})")
            }

            val loggedIn = client.login(FtpConfig.USERNAME, FtpConfig.PASSWORD)
            if (!loggedIn) {
                return@withContext Result.Failure("Login failed — check username/password in FtpConfig")
            }

            client.enterLocalPassiveMode()
            client.setFileType(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE)

            val allFiles = mutableListOf<MediaFile>()
            walkDirectory(client, FtpConfig.ROOT_PATH, allFiles, depth = 0)

            client.logout()

            val rows = allFiles
                .groupBy { it.category }
                .map { (category, files) -> MediaRow(category, files.sortedBy { it.name }) }
                .sortedBy { it.title }

            if (rows.isEmpty()) {
                Result.Failure("Connected, but found no video files under ${FtpConfig.ROOT_PATH}")
            } else {
                Result.Success(rows)
            }
        } catch (e: Exception) {
            Result.Failure(e.message ?: "Unknown FTP error")
        } finally {
            if (client.isConnected) {
                try { client.disconnect() } catch (_: Exception) {}
            }
        }
    }

    /** Recursively walks folders (bounded depth to avoid runaway loops on symlinks). */
    private fun walkDirectory(
        client: FTPClient,
        path: String,
        out: MutableList<MediaFile>,
        depth: Int
    ) {
        if (depth > 4) return
        val entries: Array<FTPFile> = client.listFiles(path) ?: return

        for (entry in entries) {
            if (entry.name == "." || entry.name == "..") continue
            val childPath = if (path.endsWith("/")) "$path${entry.name}" else "$path/${entry.name}"

            if (entry.isDirectory) {
                walkDirectory(client, childPath, out, depth + 1)
            } else if (entry.isFile && isVideo(entry.name)) {
                val category = path.substringAfterLast("/").ifBlank { "Home" }
                out.add(
                    MediaFile(
                        name = entry.name,
                        fullPath = childPath,
                        category = category,
                        sizeBytes = entry.size
                    )
                )
            }
        }
    }

    private fun isVideo(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in FtpConfig.VIDEO_EXTENSIONS
    }
}
