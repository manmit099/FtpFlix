package com.example.ftpflix.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NetflixRed = Color(0xFFE50914)
private val NearBlack = Color(0xFF141414)
private val CardGrey = Color(0xFF2A2A2A)

private val DarkColors = darkColorScheme(
    primary = NetflixRed,
    secondary = NetflixRed,
    background = NearBlack,
    surface = CardGrey,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun FtpFlixTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        content = content
    )
}
