package com.example.ftpflix

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.ftpflix.ftp.MediaFile
import com.example.ftpflix.player.PlayerActivity
import com.example.ftpflix.ui.HomeScreen
import com.example.ftpflix.ui.theme.FtpFlixTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FtpFlixTheme {
                HomeScreen(onPlay = { media -> launchPlayer(media) })
            }
        }
    }

    private fun launchPlayer(media: MediaFile) {
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_STREAM_URL, FtpConfig.streamUrl(media.fullPath))
            putExtra(PlayerActivity.EXTRA_TITLE, media.name)
        }
        startActivity(intent)
    }
}
