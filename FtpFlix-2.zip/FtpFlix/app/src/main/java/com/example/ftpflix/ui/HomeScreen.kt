package com.example.ftpflix.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ftpflix.ftp.MediaFile
import com.example.ftpflix.ftp.MediaRow
import kotlin.math.abs

@Composable
fun HomeScreen(
    onPlay: (MediaFile) -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val state = viewModel.uiState

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        when (state) {
            is HomeUiState.Loading -> LoadingState()
            is HomeUiState.Error -> ErrorState(
                message = state.message,
                onRetry = { viewModel.refresh() }
            )
            is HomeUiState.Loaded -> LibraryContent(
                rows = state.rows,
                onPlay = onPlay,
                onRefresh = { viewModel.refresh() }
            )
        }
    }
}

@Composable
private fun LoadingState() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text("Connecting to FTP server…", color = Color.White)
        }
    }
}

@Composable
private fun ErrorState(message: String, onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Couldn't load your library", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(message, color = Color.LightGray, fontSize = 14.sp)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onRetry) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Retry")
            }
        }
    }
}

@Composable
private fun LibraryContent(
    rows: List<MediaRow>,
    onPlay: (MediaFile) -> Unit,
    onRefresh: () -> Unit
) {
    val heroItem = rows.firstOrNull()?.items?.firstOrNull()

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            if (heroItem != null) {
                HeroBanner(media = heroItem, onPlay = { onPlay(heroItem) })
            } else {
                TopBar(onRefresh)
            }
        }
        items(rows) { row ->
            MediaRowSection(row = row, onPlay = onPlay)
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun TopBar(onRefresh: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("FtpFlix", color = MaterialTheme.colorScheme.primary, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        IconButton(onClick = onRefresh) {
            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
        }
    }
}

@Composable
private fun HeroBanner(media: MediaFile, onPlay: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(360.dp)
            .background(posterGradient(media.name))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color(0xFF141414)),
                        startY = 200f
                    )
                )
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp).align(Alignment.TopStart),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("FtpFlix", color = MaterialTheme.colorScheme.primary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(20.dp)
        ) {
            Text(
                text = media.name.substringBeforeLast('.'),
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onPlay,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                Spacer(Modifier.width(6.dp))
                Text("Play", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MediaRowSection(row: MediaRow, onPlay: (MediaFile) -> Unit) {
    Column(modifier = Modifier.padding(top = 20.dp)) {
        Text(
            text = row.title,
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(8.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(row.items) { media ->
                PosterCard(media = media, onClick = { onPlay(media) })
            }
        }
    }
}

@Composable
private fun PosterCard(media: MediaFile, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(120.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .width(120.dp)
                .height(170.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(posterGradient(media.name)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Play",
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = media.name.substringBeforeLast('.'),
            color = Color.White,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Deterministic gradient "poster" derived from the filename, since we're
 * not extracting real thumbnails from FTP video files. Gives each title a
 * stable, distinct-looking card without any network cost.
 */
private fun posterGradient(seed: String): Brush {
    val hue = (abs(seed.hashCode()) % 360).toFloat()
    val c1 = Color.hsv(hue, 0.55f, 0.35f)
    val c2 = Color.hsv((hue + 40f) % 360f, 0.65f, 0.55f)
    return Brush.verticalGradient(listOf(c1, c2))
}
