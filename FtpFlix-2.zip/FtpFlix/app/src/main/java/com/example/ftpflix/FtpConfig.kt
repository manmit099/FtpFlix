package com.example.ftpflix

/**
 * Hardcoded connection details for your FTP phone.
 * Edit these to match the FTP server app running on your other phone
 * (e.g. "FTP Server" app on Android usually shows this on its home screen).
 */
object FtpConfig {
    const val HOST = "10.199.226.71"   // <-- change to your phone's FTP IP
    const val PORT = 1234              // <-- change to your FTP server's port
    const val USERNAME = "pc"          // <-- change if your server requires login
    const val PASSWORD = "123456"      // <-- add a password here if your server requires one

    // Root directory to browse on the FTP server. "/" = whole share.
    const val ROOT_PATH = "/"

    // Extensions treated as playable video files
    val VIDEO_EXTENSIONS = setOf(
        "mp4", "mkv", "avi", "mov", "flv", "webm", "m4v", "wmv", "3gp", "ts"
    )

    /** Builds an ftp:// URI libVLC can stream directly, with credentials embedded. */
    fun streamUrl(remotePath: String): String {
        val userInfo = if (USERNAME.isNotBlank()) {
            "$USERNAME:$PASSWORD@"
        } else ""
        val cleanPath = if (remotePath.startsWith("/")) remotePath else "/$remotePath"
        return "ftp://$userInfo$HOST:$PORT$cleanPath"
    }
}
