package com.example.ftpflix.player

import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * Full-screen video playback backed by libVLC, the same engine VLC for
 * Android uses. libVLC understands ftp:// URIs natively, so we can hand it
 * the stream URL directly — no need to download the file first.
 */
class PlayerActivity : AppCompatActivity() {

    private lateinit var libVLC: LibVLC
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var videoLayout: VLCVideoLayout

    companion object {
        const val EXTRA_STREAM_URL = "extra_stream_url"
        const val EXTRA_TITLE = "extra_title"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        videoLayout = VLCVideoLayout(this)
        setContentView(videoLayout, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val streamUrl = intent.getStringExtra(EXTRA_STREAM_URL)
        if (streamUrl.isNullOrBlank()) {
            finish()
            return
        }

        // Reasonable defaults for streaming over a home Wi-Fi network.
        val vlcArgs = arrayListOf(
            "--no-drop-late-frames",
            "--no-skip-frames",
            "--network-caching=3000"
        )

        libVLC = LibVLC(this, vlcArgs)
        mediaPlayer = MediaPlayer(libVLC)
        mediaPlayer.attachViews(videoLayout, null, false, false)

        val media = Media(libVLC, Uri.parse(streamUrl))
        media.setHWDecoderEnabled(true, false)
        mediaPlayer.media = media
        media.release()

        mediaPlayer.play()
    }

    override fun onStop() {
        super.onStop()
        if (::mediaPlayer.isInitialized) {
            mediaPlayer.stop()
            mediaPlayer.detachViews()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::mediaPlayer.isInitialized) mediaPlayer.release()
        if (::libVLC.isInitialized) libVLC.release()
    }
}
