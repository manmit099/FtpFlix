package com.example.ftpflix.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ftpflix.ftp.FtpRepository
import com.example.ftpflix.ftp.MediaRow
import kotlinx.coroutines.launch

sealed class HomeUiState {
    data object Loading : HomeUiState()
    data class Loaded(val rows: List<MediaRow>) : HomeUiState()
    data class Error(val message: String) : HomeUiState()
}

class HomeViewModel : ViewModel() {
    private val repository = FtpRepository()

    var uiState: HomeUiState by mutableStateOf(HomeUiState.Loading)
        private set

    init {
        refresh()
    }

    fun refresh() {
        uiState = HomeUiState.Loading
        viewModelScope.launch {
            when (val result = repository.fetchLibrary()) {
                is FtpRepository.Result.Success -> uiState = HomeUiState.Loaded(result.rows)
                is FtpRepository.Result.Failure -> uiState = HomeUiState.Error(result.message)
            }
        }
    }
}
